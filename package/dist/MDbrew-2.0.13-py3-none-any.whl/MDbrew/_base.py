import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from numpy.typing import NDArray

__all__ = ["np", "pd", "plt", "NDArray"]

print(__package__)
