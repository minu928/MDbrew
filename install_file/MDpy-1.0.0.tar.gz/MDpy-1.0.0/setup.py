from setuptools import setup, find_packages

setup(
    name="MDpy",
    version="1.0.0",
    author="Knu",
    author_email="k1alty@naver.com",
    description="Postprocessing tools for the MD simulation results (ex. lammps)",
    packages=find_packages(),
)
